/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Menu as MenuIcon, 
  X, 
  Star, 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Instagram, 
  Facebook, 
  Twitter, 
  Youtube,
  ChevronRight
} from 'lucide-react';

const navLinks = [
  { name: 'Home', href: '#home' },
  { name: 'Menu', href: '#menu' },
  { name: 'About Us', href: '#about' },
  { name: 'Offers', href: '#offers' },
  { name: 'Contact', href: '#contact' },
];

const specialDishes = [
  {
    id: 1,
    title: 'Biryani Rice & Mutton',
    description: 'Authentic spiced rice with tender mutton chunks',
    price: 'Ksh 850',
    image: 'https://images.unsplash.com/photo-1589302168068-964664d93dc0?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 2,
    title: 'Signature Coffee Blend',
    description: 'Freshly roasted beans from the Kenyan highlands',
    price: 'Ksh 350',
    image: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&q=80&w=800',
  },
  {
    id: 3,
    title: 'Gourmet Platter',
    description: 'A selection of our finest appetizers and grills',
    price: 'Ksh 1,200',
    image: 'https://images.unsplash.com/photo-1603360946369-dc9bb6258143?auto=format&fit=crop&q=80&w=800',
  },
];

const testimonials = [
  {
    id: 1,
    name: 'Emma R.',
    text: 'Absolutely fantastic! The food was delicious and the atmosphere was perfect. Highly recommended!',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=150&h=150',
  },
  {
    id: 2,
    name: 'David K.',
    text: 'The best Biryani in Nakuru. The service is impeccable and the coffee lounge is so relaxing.',
    rating: 5,
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=150&h=150',
  },
];

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const fadeIn = {
    initial: { opacity: 0, y: 20 },
    whileInView: { opacity: 1, y: 0 },
    viewport: { once: true },
    transition: { duration: 0.8 }
  };

  return (
    <div className="min-h-screen bg-dark-bg selection:bg-gold selection:text-darker-bg">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-darker-bg/95 backdrop-blur-md py-3 shadow-lg' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-serif font-bold text-gold tracking-tighter">JAMIA</span>
            <span className="hidden sm:block text-xs uppercase tracking-[0.3em] text-cream/60 mt-1">Lounge</span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <a 
                key={link.name} 
                href={link.href} 
                className="text-sm uppercase tracking-widest text-white hover:text-gold transition-colors duration-300"
              >
                {link.name}
              </a>
            ))}
            <button className="bg-gold hover:bg-gold-dark text-darker-bg px-6 py-2.5 rounded-full font-bold text-sm uppercase tracking-wider transition-all duration-300 hover:scale-105 active:scale-95">
              Reservation
            </button>
          </div>

          {/* Mobile Toggle */}
          <button className="md:hidden text-gold" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={28} /> : <MenuIcon size={28} />}
          </button>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-darker-bg border-b border-gold/10 overflow-hidden"
            >
              <div className="flex flex-col p-6 gap-4">
                {navLinks.map((link) => (
                  <a 
                    key={link.name} 
                    href={link.href} 
                    onClick={() => setIsMenuOpen(false)}
                    className="text-lg text-cream hover:text-gold transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
                <button className="bg-gold text-darker-bg w-full py-3 rounded-lg font-bold uppercase mt-2">
                  Reservation
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 z-0 parallax-bg"
          style={{ 
            backgroundImage: 'url("https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=1920")',
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-darker-bg/80 via-darker-bg/40 to-dark-bg" />
        </div>

        <div className="relative z-10 text-center px-6 max-w-4xl">
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="text-gold font-cursive text-3xl mb-2"
          >
            Welcome to
          </motion.p>
          <motion.h1 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="text-6xl md:text-8xl font-serif font-bold text-white mb-4 tracking-tight"
          >
            Jamia Food Mart
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-xl md:text-2xl font-serif italic text-cream/80 mb-8 tracking-[0.2em] uppercase"
          >
            & Coffee Lounge
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1.2 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <button className="border border-gold text-gold hover:bg-gold hover:text-darker-bg px-10 py-4 rounded-full font-bold uppercase tracking-widest transition-all duration-300">
              View Menu
            </button>
            <button className="bg-gold text-darker-bg hover:bg-gold-dark px-10 py-4 rounded-full font-bold uppercase tracking-widest transition-all duration-300 shadow-[0_0_20px_rgba(212,165,52,0.4)]">
              Book a Table
            </button>
          </motion.div>
        </div>

        {/* Decorative elements */}
        <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-gold/50">
          <div className="w-px h-12 bg-gradient-to-b from-gold to-transparent" />
        </div>
      </section>

      {/* Special Dishes */}
      <section id="menu" className="py-24 px-6 bg-darker-bg">
        <div className="max-w-7xl mx-auto">
          <motion.div {...fadeIn} className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif mb-4">
              Our <span className="font-cursive text-gold italic">Special</span> Dishes
            </h2>
            <p className="text-gold tracking-[0.3em] uppercase text-sm">── Taste the Best of Our Cuisine ──</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {specialDishes.map((dish, idx) => (
              <motion.div 
                key={dish.id}
                {...fadeIn}
                transition={{ delay: idx * 0.2 }}
                className="group bg-dark-bg rounded-2xl overflow-hidden border border-white/5 hover:border-gold/30 transition-all duration-500 hover:-translate-y-2 golden-glow"
              >
                <div className="h-64 overflow-hidden relative">
                  <img 
                    src={dish.image} 
                    alt={dish.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-dark-bg via-transparent to-transparent opacity-60" />
                </div>
                <div className="p-8 text-center">
                  <h3 className="text-2xl font-cursive text-gold mb-2">{dish.title}</h3>
                  <p className="text-cream/60 text-sm mb-4 h-10">{dish.description}</p>
                  <p className="text-2xl font-serif text-gold font-bold mb-6">{dish.price}</p>
                  <button className="bg-amber-warm hover:bg-gold text-white hover:text-darker-bg px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest transition-all duration-300">
                    Order Now
                  </button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Us */}
      <section id="about" className="relative py-24 overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 flex flex-col lg:flex-row items-center gap-16">
          <motion.div {...fadeIn} className="flex-1 space-y-8">
            <div className="space-y-4">
              <p className="text-gold tracking-[0.3em] uppercase text-xs flex items-center gap-4">
                <span className="w-8 h-px bg-gold" /> Discover Our Story
              </p>
              <h2 className="text-4xl md:text-5xl font-serif leading-tight">
                Fine Dining & <br />
                <span className="text-gold italic">Perfect Ambience</span>
              </h2>
            </div>
            <p className="text-cream/70 text-lg leading-relaxed max-w-xl">
              Located in the heart of Nakuru, Jamia Food Mart & Coffee Lounge is more than just a restaurant. 
              We are a sanctuary for food lovers, blending traditional flavors with modern elegance. 
              From our legendary Biryani to our artisan coffee, every dish is a masterpiece crafted with passion.
            </p>
            <div className="grid grid-cols-2 gap-6 py-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold">
                  <Star size={20} />
                </div>
                <span className="text-sm font-serif italic">4.4 Rating</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gold/10 flex items-center justify-center text-gold">
                  <Clock size={20} />
                </div>
                <span className="text-sm font-serif italic">Open Daily</span>
              </div>
            </div>
            <button className="border border-gold text-gold hover:bg-gold hover:text-darker-bg px-8 py-3 rounded-full font-bold uppercase tracking-widest transition-all duration-300">
              More About Us
            </button>
          </motion.div>

          <motion.div 
            {...fadeIn}
            className="flex-1 relative"
          >
            <div className="relative z-10 rounded-2xl overflow-hidden border-2 border-gold/20 shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1550966842-2849a28c0a28?auto=format&fit=crop&q=80&w=1200" 
                alt="Restaurant Interior"
                referrerPolicy="no-referrer"
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gold/5 mix-blend-overlay" />
            </div>
            {/* Decorative frames */}
            <div className="absolute -top-6 -right-6 w-full h-full border border-gold/30 rounded-2xl -z-10" />
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-gold/10 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 px-6 bg-darker-bg relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-gold/30 to-transparent" />
        
        <div className="max-w-4xl mx-auto text-center">
          <motion.div {...fadeIn} className="mb-12">
            <h2 className="text-4xl md:text-5xl font-serif mb-4">
              Customer <span className="font-cursive text-gold italic">Reviews</span>
            </h2>
            <p className="text-cream/60 tracking-widest uppercase text-sm">What Our Guests Say</p>
          </motion.div>

          <div className="relative">
            {testimonials.map((t, idx) => (
              <motion.div 
                key={t.id}
                {...fadeIn}
                className="bg-dark-bg p-10 rounded-3xl border border-white/5 relative golden-glow mb-8"
              >
                <div className="absolute -top-8 left-1/2 -translate-x-1/2">
                  <div className="w-16 h-16 rounded-full border-2 border-gold p-1 bg-darker-bg">
                    <img src={t.image} alt={t.name} className="w-full h-full rounded-full object-cover" />
                  </div>
                </div>
                <div className="flex justify-center gap-1 mb-6 mt-4">
                  {[...Array(t.rating)].map((_, i) => (
                    <Star key={i} size={16} className="fill-gold text-gold" />
                  ))}
                </div>
                <p className="text-xl md:text-2xl font-serif italic text-cream/90 mb-6 leading-relaxed">
                  "{t.text}"
                </p>
                <h4 className="text-gold font-bold tracking-widest uppercase text-sm">{t.name}</h4>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer id="contact" className="bg-darker-bg pt-24 pb-12 px-6 border-t border-white/5">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <h3 className="text-gold font-serif text-2xl">Opening Hours</h3>
            <div className="space-y-2 text-cream/60 text-sm">
              <p className="flex justify-between"><span>Mon - Fri:</span> <span>12:00 PM - 10:00 PM</span></p>
              <p className="flex justify-between"><span>Sat - Sun:</span> <span>10:00 AM - 11:00 PM</span></p>
              <p className="pt-4 text-gold/80 italic">Open now · Closes 9:30 PM</p>
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="text-gold font-serif text-2xl">Quick Links</h3>
            <ul className="space-y-3">
              {navLinks.map(link => (
                <li key={link.name}>
                  <a href={link.href} className="text-cream/60 hover:text-gold text-sm transition-colors flex items-center gap-2">
                    <ChevronRight size={14} /> {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6">
            <h3 className="text-gold font-serif text-2xl">Get in Touch</h3>
            <div className="flex gap-4">
              {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full border border-gold/30 flex items-center justify-center text-gold hover:bg-gold hover:text-darker-bg transition-all duration-300">
                  <Icon size={18} />
                </a>
              ))}
            </div>
            <p className="text-cream/40 text-xs italic">Follow us for daily specials and offers.</p>
          </div>

          <div className="space-y-6">
            <h3 className="text-gold font-serif text-2xl">Contact Info</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-3 text-cream/60 text-sm">
                <MapPin size={18} className="text-gold shrink-0" />
                <span>Oginga Odinga Ave, Nakuru, Kenya</span>
              </div>
              <div className="flex items-center gap-3 text-cream/60 text-sm">
                <Phone size={18} className="text-gold shrink-0" />
                <span>0719 311748</span>
              </div>
              <div className="flex items-center gap-3 text-cream/60 text-sm">
                <Mail size={18} className="text-gold shrink-0" />
                <span>info@jamiafoodmart.com</span>
              </div>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-8 border-t border-white/5 text-center">
          <p className="text-cream/30 text-xs tracking-widest uppercase">
            &copy; {new Date().getFullYear()} Jamia Food Mart & Coffee Lounge. All Rights Reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
